<template>
  <admin />
</template>

<script>
import admin from "../components/admin";

export default {
  name: "/",

  components: {
    admin,
  },
};
</script>
