<template>
  <h2 class="d-flex justify-center align-center">각 지역 온도 알림</h2>
</template>

<script>
export default {
  data() {
    return {
      property: "value",
    };
  },
};
</script>

<style></style>
